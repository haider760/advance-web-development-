
document.getElementById('year').textContent = new Date().getFullYear();


const themeToggle = document.getElementById('themeToggle');
if (localStorage.getItem('theme') === 'light') {
  document.body.classList.add('light');
}
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('light');
  const theme = document.body.classList.contains('light') ? 'light' : 'dark';
  localStorage.setItem('theme', theme);
});


const header = document.getElementById('header');
window.addEventListener('scroll', () => {
  if (window.scrollY > 100) header.classList.add('header-small');
  else header.classList.remove('header-small');
});


const fadeEls = document.querySelectorAll('.fade-in');
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('show');
  });
}, { threshold: 0.2 });
fadeEls.forEach(el => observer.observe(el));


const modal = document.getElementById('contactModal');
const openModal = document.getElementById('openModal');
const closeModal = document.getElementById('closeModal');

openModal.addEventListener('click', () => {
  modal.classList.add('show');
  modal.classList.remove('hidden');
});

closeModal.addEventListener('click', () => {
  modal.classList.remove('show');
  setTimeout(() => modal.classList.add('hidden'), 300);
});

window.addEventListener('click', e => {
  if (e.target === modal) {
    modal.classList.remove('show');
    setTimeout(() => modal.classList.add('hidden'), 300);
  }
});


const form = document.getElementById('contactForm');
form.addEventListener('submit', e => {
  e.preventDefault();
  const name = document.getElementById('name').value;
  alert(`Thank you, ${name}! Your message has been received (demo mode only).`);
  form.reset();
  modal.classList.remove('show');
  setTimeout(() => modal.classList.add('hidden'), 300);
});
